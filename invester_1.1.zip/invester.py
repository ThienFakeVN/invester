import random

money = 100
current_turns = 1

print(f'Bạn có {money}$. Bạn đi đầu tư. Đầu tư vào đâu bạn đừng bận tâm.')

def turns_play():
    global turns, number_turns
    turns = input('Chọn sô lượt bạn sẽ chơi (gõ "vô hạn" nếu bạn không muốn trò chơi dừng lại): ')
    if turns == "vô hạn":
        number_turns = None
        print('Bạn chơi chế độ vô hạn,\033[1m trò chơi sẽ kết thúc khi bạn hết tiền\033[0m.')
    else:
        try:
            number_turns = int(turns)
        except ValueError:
            print('Bạn cần phải nhập một con số.')
            turns_play()

def invest_money_input():
    global invest_money
    try:
        invest_money = int(input('Chọn số tiền bạn đầu tư: '))
        if invest_money > money and number_turns == None:
            print('Số tiền bạn đầu tư không thể lớn hơn số tiền bạn hiện có.')
            invest_money_input()
        if invest_money <= 0:
            print('Số tiền bạn nhập phải lớn hơn 0.')
            invest_money_input()
    except ValueError:
        print('Bạn cần phải nhập một con số.')
        invest_money_input()

def investing():
    global money
    money += invest_money * random.randint(-10, 10)
    print(f'Số tiền sau khi đầu tư: {money}')
    if money <= 0 and number_turns == None:
        print('Bạn đã thua!')
        input()
        exit()

turns_play()

if number_turns != None:
    while current_turns <= number_turns:
        print(f'Lượt: {current_turns}.')
        invest_money_input()
        investing()
        current_turns += 1
    print(f'Tổng số tiền của bạn sau {turns} lượt là {money}.')
else:
    while current_turns:
        print(f'Lượt: {current_turns}.')
        invest_money_input()
        investing()
        current_turns += 1

input() 